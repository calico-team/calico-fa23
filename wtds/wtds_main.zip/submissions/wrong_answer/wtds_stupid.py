input()
print('queueon', flush= True)
print('heapeon', flush= True)
print('heapeon', flush= True)
