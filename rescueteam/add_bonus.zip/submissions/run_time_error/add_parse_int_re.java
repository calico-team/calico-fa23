import java.io.*;

class Solution {
    /**
     * Implements addition with Java's fixed precision int. Crashes because
     * large values in the bonus test set exceeds Integer.MAX_VALUE.
     */
    static int solve(int A, int B) {
        return A + B;
    }
    
    static BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
    static PrintWriter out = new PrintWriter(System.out);

    public static void main(String[] args) throws IOException {
        int T = Integer.parseInt(in.readLine());
        for (int i = 0; i < T; i++) {
            String[] AB = in.readLine().split(" ");
            int A = Integer.parseInt(AB[0]);
            int B = Integer.parseInt(AB[1]);
            out.println(solve(A, B));
        }
        out.flush();
    }
}
