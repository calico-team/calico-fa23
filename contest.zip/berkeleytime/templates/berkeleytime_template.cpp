#include <iostream>

using namespace std;

/**
 * Return the appropriate text given the contest will start N minutes late.
 * 
 * N: the number of minutes late the contest will start
 */
string solve(int N) {
    // YOUR CODE HERE
    return -1;
}

int main() {
    int T;
    cin >> T;
    for (int i = 0; i < T; i++) {
        int N;
        cin >> N;
        cout << solve(N) << '\n';
    }
}
