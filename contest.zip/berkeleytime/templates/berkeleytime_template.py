def solve(N: int) -> str:
    """
    Return the appropriate text given the contest will start N minutes late.
    
    N: the number of minutes late the contest will start
    """
    # YOUR CODE HERE
    return 0


def main():
    T = int(input())
    for _ in range(T):
        N = int(input())
        print(solve(N))


if __name__ == '__main__':
    main()
