def solve(N: int) -> int:
    """
    Return the number of days between Year 0 and Big Ben's Birthday
    
    N: The number of years before Big Ben's Birthday
    """
    # YOUR CODE HERE
    return -1


def main():
    T = int(input())
    for _ in range(T):
        N = int(input())
        print(solve(N))


if __name__ == '__main__':
    main()
