"""This is expected to RTE on submission because numpy is not supported"""

import sys

import numpy as np


sys.set_int_max_str_digits(10 ** 6)

"""Precomputed Augmented Border State Transition Matrix

See benga/experiments/misc/make_matrix.py for an explanation.
"""
A_1 = np.array([
    [2, 0, 4, 0, 0, 0, 2, 0, 4, 0, 0, 0, 0, 0, 0, 2, 0, 1, 1],
    [1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0],
    [1, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0],
    [1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 1, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0],
    [0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0],
    [1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
], dtype=np.int64)
dim_A = 19

I = np.identity(dim_A, dtype=np.int64)
A = [I, A_1]

MOD = 2 ** (3 ** 2) * 3 ** (2 ** 3)

"""Precomputed Matrix Power Cycle Length

See benga/submissions/accepted/benga_cycles.cpp for an explanation.
"""
LAMBDA = 84 * 312 * 6 * MOD


def solve(N: int) -> int:
    A_N = mat_pow_mod(A, (N // 3) % LAMBDA + LAMBDA)
    return (A_N[0][-1] + A_N[0][0] - 1) % MOD


def mat_pow_mod(A, n):
    result = np.copy(I)
    bin_n = bin(n)
    for i in range(1, len(bin_n) - 1):
        if bin_n[-i] == '1':
            result = A[i] @ result % MOD
        if len(A) < i + 2:
            A.append(A[-1] @ A[-1] % MOD)
    return result


def main():
    T = int(input())
    for _ in range(T):
        N = int(input())
        print(solve(N))


if __name__ == '__main__':
    main()
